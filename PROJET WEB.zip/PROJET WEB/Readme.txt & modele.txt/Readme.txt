NOM			PRENOM			NIVEAU		VACATION
Marcelin		John Wesley		2eme Annee	MEDIAN