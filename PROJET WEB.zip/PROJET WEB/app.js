setTimeout(() => {
    document.querySelector('.preloader').style.display ="none"  
}, 2240);

